const express = require('express');
const path = require('path');
const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public')); 
app.use(express.urlencoded({ extended: true })); 

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Projects.html'));
});

app.get('/cadastra', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Cadastro.html'));
});

app.post('/cadastra', (req, res) => {
    const { usuario } = req.body;
    res.render('resposta', { status: 'Cadastro realizado', usuario: usuario });
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Login.html'));
});

app.post('/login', (req, res) => {
    const { usuario } = req.body;
    res.render('resposta', { status: 'Login efetuado', usuario: usuario });
});

app.listen(80, () => {
    console.log("Servidor rodando na porta 80");
});