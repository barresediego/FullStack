const express = require('express');
const path = require('path');
const { cadastrarPost, buscarPosts } = require('./db');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/', (req, res) => {
  res.redirect('/projects.html');
});

app.get('/blog', (req, res) => {
  buscarPosts((err, posts) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erro ao buscar posts.');
    }
    res.render('blog', { posts });
  });
});


app.get('/cadastrar_post', (req, res) => {
  res.render('cadastrar_post');
});

app.post('/cadastrar_post', (req, res) => {
  const { titulo, resumo, conteudo } = req.body;

  if (!titulo || !resumo || !conteudo) {
    return res.status(400).send('Todos os campos são obrigatórios.');
  }

  cadastrarPost(titulo, resumo, conteudo, (err, id) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Erro ao cadastrar post.');
    }
    res.send(`
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <meta charset="UTF-8">
        <title>Post Cadastrado</title>
        <link rel="stylesheet" href="/style.css">
      </head>
      <body>
        <div class="container confirmacao">
          <h2>Post Cadastrado!</h2>
          <p>Seu post foi salvo com sucesso.</p>
          <a href="/">Home</a> | <a href="/blog">Ver Blog</a>
        </div>
      </body>
      </html>
    `);
  });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
  console.log(`  → Projetos: http://localhost:${PORT}/`);
  console.log(`  → Blog:     http://localhost:${PORT}/blog`);
});