const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./blog.db', (err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err.message);
  } else {
    console.log('Conectado ao banco de dados SQLite.');
  }
});

db.run(`
  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    resumo TEXT NOT NULL,
    conteudo TEXT NOT NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

function cadastrarPost(titulo, resumo, conteudo, callback) {
  const sql = `INSERT INTO posts (titulo, resumo, conteudo) VALUES (?, ?, ?)`;
  db.run(sql, [titulo, resumo, conteudo], function (err) {
    callback(err, this ? this.lastID : null);
  });
}

function buscarPosts(callback) {
  const sql = `SELECT * FROM posts ORDER BY criado_em DESC`;
  db.all(sql, [], (err, rows) => {
    callback(err, rows);
  });
}

module.exports = { cadastrarPost, buscarPosts };